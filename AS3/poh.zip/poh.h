#ifndef POH
#define POH

void dlp(mpz_t rop, const mpz_t p, const mpz_t g, const mpz_t x);


#endif
